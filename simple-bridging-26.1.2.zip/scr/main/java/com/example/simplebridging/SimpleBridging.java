package com.example.simplebridging;

import net.fabricmc.api.ModInitializer;

public class SimpleBridging implements ModInitializer {
    public static final String MOD_ID = "simplebridging";

    @Override
    public void onInitialize() {
        // Main entrypoint
    }
}

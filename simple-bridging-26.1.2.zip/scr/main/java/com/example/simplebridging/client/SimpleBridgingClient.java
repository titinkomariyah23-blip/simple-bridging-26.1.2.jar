package com.example.simplebridging.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class SimpleBridgingClient implements ClientModInitializer {
    public static KeyBinding bridgeKey;

    @Override
    public void onInitializeClient() {
        // Register Tombol B
        bridgeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.simplebridging.bridge",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_B,
            "category.simplebridging.title"
        ));

        // Tick loop
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.getWindow() == null) return;

            long window = client.getWindow().getHandle();

            // Cek hold kombinasi: Left Alt + Left Shift + B
            boolean isAltPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
            boolean isShiftPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS;
            boolean isBPressed = bridgeKey.isPressed();

            if (isAltPressed && isShiftPressed && isBPressed) {
                // Boost movement speed (normal walk speed = 0.1f)
                client.player.getAbilities().setWalkSpeed(0.28f);

                // Auto clicker klik kanan tanpa delay
                if (client.crosshairTarget != null) {
                    client.doItemUse();
                }
            } else {
                // Return to normal speed saat dilepas
                if (client.player.getAbilities().getWalkSpeed() != 0.1f) {
                    client.player.getAbilities().setWalkSpeed(0.1f);
                }
            }
        });
    }
}
